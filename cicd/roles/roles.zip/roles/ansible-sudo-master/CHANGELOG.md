<a name="1.14.1"></a>
### 1.14.1 (2020-04-02)


#### Bug Fixes

*   case sensitive FreeBSD and visudo path ([c0b79a34](https://github.com/weareinteractive/ansible-sudo/commit/c0b79a3418820b8b1cc48e26604150d5eebc7652))



<a name="1.14.0"></a>
## 1.14.0 (2019-12-24)


#### Features

*   add os specific visudo path Merge branch 'thalunil-openbsd' ([4515d663](https://github.com/weareinteractive/ansible-sudo/commit/4515d6632b648898f9422cce65caa7489e4813b5))



<a name="1.13.1"></a>
### 1.13.1 (2019-10-17)


#### Bug Fixes

*   add full path for visudo ([04e77cef](https://github.com/weareinteractive/ansible-sudo/commit/04e77cefcd6ead9d94f0a234fcc29b008f87aa7f))



<a name="1.13.0"></a>
## 1.13.0 (2019-06-17)


#### Features

*   Allow setting sudoers directory path ([3ee4a068](https://github.com/weareinteractive/ansible-sudo/commit/3ee4a068b77d431dd75edabedc646fd5fa946c98))



<a name="1.12.3"></a>
### 1.12.3 (2019-05-15)




<a name="1.12.2"></a>
### 1.12.2 (2019-03-16)




<a name="1.12.1"></a>
### 1.12.1 (2019-03-16)


#### Features

*   add .ansible-lint ([5f1767a8](https://github.com/weareinteractive/ansible-sudo/commit/5f1767a886f5f48b5a79bc78988534358ace15f5))



<a name="1.12.0"></a>
## 1.12.0 (2018-11-10)


#### Features

*   add multiple commands ([f6bb707c](https://github.com/weareinteractive/ansible-sudo/commit/f6bb707c07f56b7f3e2b995553ad03dc6a6c3612))



<a name="1.11.0"></a>
## 1.11.0 (2018-11-10)




<a name="1.10.0"></a>
## 1.10.0 (2018-11-01)


#### Features

*   add file name to config task name ([b75c2b6d](https://github.com/weareinteractive/ansible-sudo/commit/b75c2b6d3129804fa6af14b5da7af11ae3acc4b7))



<a name="1.9.0"></a>
## 1.9.0 (2018-03-08)


#### Features

*   optionally purge other sudoers files ([969e43a6](https://github.com/weareinteractive/ansible-sudo/commit/969e43a6ff6b8a0934bb7932fd1547e389f1ffc9))



<a name="1.8.0"></a>
## 1.8.0 (2018-02-05)


#### Features

*   adopt code for ansible 2.4 ([53651d30](https://github.com/weareinteractive/ansible-sudo/commit/53651d30b7466ec2bab11abc45344bd6d1af30e2))
*   add openbsd support ([3c2a7f67](https://github.com/weareinteractive/ansible-sudo/commit/3c2a7f676f03a041b5bcf433f383fccce2945e79))



<a name="1.7.1"></a>
### 1.7.1 (2017-06-27)


#### Features

*   update apt caches on install ([0c5e4ef9](https://github.com/weareinteractive/ansible-sudo/commit/0c5e4ef9ee0f0c95f633695684b1839e474405c5))



<a name="1.7.0"></a>
## 1.7.0 (2017-05-24)


#### Features

*   update to ansible min version 2.0 ([d78f975f](https://github.com/weareinteractive/ansible-sudo/commit/d78f975ffe44be933c3f85cf12cc3bf5a1b5dce6))
*   add sudoers file variable ([7b1497a6](https://github.com/weareinteractive/ansible-sudo/commit/7b1497a6a1aeee4d32e37d8e5c683fce39cd833a))



<a name="1.6.0"></a>
## 1.6.0 (2017-01-16)


#### Features

*   add groups parameters ([043e984d](https://github.com/weareinteractive/ansible-sudo/commit/043e984d819fcf5e0efb5dbcfe1fd56320c5599c))
*   add changelog ([44c1ba22](https://github.com/weareinteractive/ansible-sudo/commit/44c1ba221d9bfc237909358852f4d7506f40da25))



<a name="1.5.0"></a>
## 1.5.0 (2015-10-26)


#### Breaking Changes

*   change default of item.users to ALL ([d08df275](https://github.com/weareinteractive/ansible-sudo/commit/d08df275b43b4bf82530c21db97dcd92804a3dda), closes [#7](https://github.com/weareinteractive/ansible-sudo/issues/7), breaks [#](https://github.com/weareinteractive/ansible-sudo/issues/))

#### Features

*   change default of item.users to ALL ([d08df275](https://github.com/weareinteractive/ansible-sudo/commit/d08df275b43b4bf82530c21db97dcd92804a3dda), closes [#7](https://github.com/weareinteractive/ansible-sudo/issues/7), breaks [#](https://github.com/weareinteractive/ansible-sudo/issues/))
*   added changelog ([02f331d5](https://github.com/weareinteractive/ansible-sudo/commit/02f331d5bbaf2e2c80e4f9ef8f61611bdb3d7324))
